# P1-B 修订报告（v3：定点修订 + Tika 实测 + 可执行重复校验）

> 状态：**完成，待审核**。未提交 Git，未调用 Embedding/Chat/Rerank，未连接数据库。

## 1. 本轮修订目标

v2 已用 Java 生产类完成离线切分、证据映射和候选 gold。v3 针对 Codex 复核提出的 5 个修订区域：

1. **修正 candidate gold**：q01/q03 `supportsAnswerPoints` 不完整、q07 缺 SpringDoc 证据、校验器需拒绝空 `supportingChunkIds`、区分多要点 vs 多 chunk 组合
2. **离线工具移到 test 作用域**：避免新增 main 源码
3. **明确 Tika 输入契约**：不再声称「对 .md 无影响」，改为实测验证
4. **重复运行校验改为实际可执行**：不再硬编码 PASS，实际运行两次比较 SHA-256
5. **更新文档和验证脚本**：反映以上所有变更

## 2. 完成事项

### 2.1 修正 candidate gold

**queries.draft.json 修正**：
- q01：evidence[0] `supportsAnswerPoints` [1] → [1, 2]（引句「后端服务启动于 `http://localhost:8080`」同时覆盖端口和地址两个要点）
- q03：两条 evidence 的 `supportsAnswerPoints` [1] → [1, 2]（两条引句各自覆盖两个要点）
- q07：新增 evidence[1]，引句来自 ig-readme-root 第 431 行 `SpringDoc/Swagger UI`，覆盖答案要点 2

**evidence 总数**：50 → 51（新增 1 条 answerable evidence）

**candidate_gold_builder.py 重写**：
- 区分 `multipleAnswerPoints`（有多个答案要点）与 `multipleChunkCombinationRequired`（需要多 chunk 组合）
- 16 道可答题中：11 道有多个要点，其中 7 道需要多 chunk 组合，4 道单 chunk 已覆盖全部要点
- 校验 ANSWERABLE 题的 `allCandidateChunkIds` 和每个 answerPoint 的 `supportingChunkIds` 非空
- 结果：0 校验错误

### 2.2 离线工具移到 test 作用域

**变更**：
- `app/src/main/java/interview/guide/eval/OfflineChunker.java` → `app/src/test/java/interview/guide/eval/OfflineChunker.java`
- `app/build.gradle`：`evalOfflineChunk` 任务的 classpath 从 `sourceSets.main.runtimeClasspath` 改为 `sourceSets.test.runtimeClasspath`
- 新增 `TikaDifferenceVerifier.java` 也在 test 作用域

**效果**：不新增 main 源码，评测工具完全隔离在 test 作用域。

### 2.3 Tika 差异实测验证

**新增工具**：`TikaDifferenceVerifier.java`（test 作用域），通过 `./gradlew :app:evalVerifyTika` 运行。

**方法**：逐文件对比两条路径：
- 路径 A（OfflineChunker）：`rawText → TextCleaningService.cleanText()`
- 路径 B（生产上传）：`rawBytes → DocumentParseService.parseContent(bytes, fileName)`（Tika + clean）

**结果**：

| 文档 | 结果 | 说明 |
|------|------|------|
| ig-db-migration-readme | PASS | 458 chars，完全一致 |
| ig-githooks-readme | PASS | 318 chars，完全一致 |
| ig-kb-interview-capacity-tdd | PASS | 1816 chars，完全一致 |
| ig-kb-question-gen-async-tdd | PASS | 3087 chars，完全一致 |
| ig-readme-root | **DIFF** | cleanOnly=18008 vs tikaThenClean=17901，差 107 字符 |
| ig-setup-api-keys | PASS | 2378 chars，完全一致 |
| ig-voice-arch | PASS | 10367 chars，完全一致 |

**差异原因**：Tika AutoDetectParser 将 ig-readme-root.md 开头的 `<div align="center">...</div>` HTML 标签剥离。语义内容（标题、文本、链接、表格）不受影响。

**决策**：离线评测跳过 Tika。差异仅为 HTML 装饰标签，不影响语义检索。已记录在 `chunk-manifest.json` 的 `parsingPolicy.tikaVerification` 中。

### 2.4 重复运行校验改为实际可执行

**validate_p1b.py v3 变更**：
- 第 5 项检查不再硬编码 PASS，改为实际运行 `./gradlew :app:evalOfflineChunk` 两次
- 比较两次 `chunks.jsonl` 的 SHA-256
- 运行结束后恢复原始 `chunks.jsonl`
- Windows 兼容：自动检测 `gradlew.bat`

**结果**：
```
运行 #1 SHA-256: 31da4cd0d03c69005d2ef867
运行 #2 SHA-256: 31da4cd0d03c69005d2ef867
[PASS] 两次运行 chunks.jsonl 完全一致
```

### 2.5 校验器增强

**validate_p1b.py v3 新增检查**：
- ANSWERABLE 题的每个 answerPoint 的 `supportingChunkIds` 必须非空
- `allCandidateChunkIds` 必须非空
- 发现空值时明确报告 queryId 和 answerPointIndex

## 3. 验证结果

运行 `validate_p1b.py`，所有检查通过：

```
=== 验证汇总 ===
  [PASS] 语料哈希
  [PASS] Evidence 引句（51 条全部命中）
  [PASS] Chunk 完整性（28 chunks，0 U+FFFD）
  [PASS] 映射完整性（51 条已映射，0 悬空）
  [PASS] 重复运行校验（实际两次运行 SHA-256 一致）
  [PASS] Candidate Gold（16 可答题有 gold，4 无答案无 gold，0 空 supportingChunkIds）
```

## 4. 文件清单

```
eval/datasets/devsupport-v0.1/
├── corpus/                          # 7 份文档逐字节副本（未改动）
├── corpus-manifest.json             # 未改动
├── queries.draft.json               # v3 修订：q01/q03 supportsAnswerPoints，q07 新增 evidence
├── chunks.jsonl                     # 28 个 chunks（未改动）
├── chunk-manifest.json              # v3 修订：parsingPolicy 增加 tikaVerification
├── evidence-chunk-map.json          # v3 修订：51 条映射（原 50 条）
├── candidate-gold.json              # v3 修订：多要点/多 chunk 区分，空 supportingChunkIds 校验
├── README.md                        # v3 修订：反映所有变更
├── P1B-REPORT.md                    # 本文件（v3 重写）
├── evidence_chunk_mapper.py         # 未改动
├── candidate_gold_builder.py        # v3 重写：多要点/多 chunk 区分
└── validate_p1b.py                  # v3 重写：实际重复运行 + 空 supportingChunkIds 校验

app/src/test/java/interview/guide/eval/
├── OfflineChunker.java              # 从 main 移到 test 作用域
└── TikaDifferenceVerifier.java      # v3 新增：Tika 差异验证

app/build.gradle
├── evalOfflineChunk task            # v3 修订：classpath 改为 test
└── evalVerifyTika task              # v3 新增：Tika 差异验证任务
```

## 5. 与生产代码的对比

| 步骤 | 生产代码 | 离线工具 | 差异 |
|------|---------|---------|------|
| 文本解析 | `DocumentParseService.parseContent()` (Tika) | 直接读 `.md` 文件 | **实测验证**：6/7 文件无差异，ig-readme-root 差 107 字符（HTML 标签剥离） |
| 文本清洗 | `TextCleaningService.cleanText()` | 直接调用同一方法 | **完全一致** |
| 文本切分 | `TokenTextSplitter.builder().build()` | 直接调用同一构造 | **完全一致** |
| 向量化 | `VectorStore.add()` | 未执行 | **不涉及**：本轮只做离线切分 |

## 6. 统计摘要

| 指标 | 数值 |
|------|------|
| 语料文档 | 7 份 |
| 语料字符数（Java） | 39,094 |
| 清洗后字符数 | 36,432 |
| 切分 chunks | 28 |
| U+FFFD 总数 | 0 |
| Evidence 总数 | 51（46 answerable + 5 nearMiss） |
| 已映射 evidence | 51 (100%) |
| 跨 chunk evidence | 0 (0%) |
| 可答题 | 16 |
| 无答案题 | 4 |
| 多要点题 | 11 |
| 需多 chunk 组合 | 7 |
| Tika 差异文件 | 1/7（ig-readme-root，107 字符 HTML 标签） |

## 7. 下一步

- 等待 Codex 复核
- 复核通过后，可进入 P1-C（真实检索评测）或 P2（Hybrid 检索实现）

---

**执行命令记录**：
```bash
# 离线切分
./gradlew :app:evalOfflineChunk

# Tika 差异验证
./gradlew :app:evalVerifyTika

# 证据映射
cd eval/datasets/devsupport-v0.1
python evidence_chunk_mapper.py

# 候选 gold 整理
python candidate_gold_builder.py

# 综合验证（含实际重复运行比较）
python validate_p1b.py
```

**退出码**：所有命令退出码均为 0（成功）。
