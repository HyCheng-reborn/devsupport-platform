#!/usr/bin/env python3
"""
P1-B 综合验证脚本（v3）。

检查项：
  1. 语料哈希：7 份文档 SHA-256 与 corpus-manifest.json 一致
  2. Evidence 引句：全部逐字命中语料（归一化后）
  3. Chunk 完整性：chunk 无 U+FFFD，chunkId 唯一
  4. Evidence→Chunk 映射：所有 evidence 已映射，无悬空引用
  5. 重复运行校验：实际运行两次 chunker，比较 chunks.jsonl SHA-256
  6. Candidate Gold：可答题有 gold 且 supportingChunkIds 非空，无答案题无正例 gold
"""

import json
import hashlib
import subprocess
import sys
import tempfile
import shutil
from pathlib import Path

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()

def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()

def normalize_text(text):
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    lines = text.split('\n')
    lines = [line.rstrip() for line in lines]
    return '\n'.join(lines)

def main():
    sys.stdout.reconfigure(encoding='utf-8')
    base_dir = Path(__file__).parent
    results = []

    # 1. 语料哈希校验
    print('=== 1. 语料哈希校验 ===')
    corpus_dir = base_dir / 'corpus'
    with open(base_dir / 'corpus-manifest.json', 'r', encoding='utf-8') as f:
        corpus_manifest = json.load(f)

    hash_ok = True
    for doc in corpus_manifest['documents']:
        doc_id = doc['docId']
        file_path = corpus_dir / f'{doc_id}.md'
        actual_hash = sha256_file(file_path)
        expected_hash = doc['originalSha256']
        if actual_hash == expected_hash:
            print(f'  [PASS] {doc_id}')
        else:
            print(f'  [FAIL] {doc_id}: expected {expected_hash[:12]}, got {actual_hash[:12]}')
            hash_ok = False
    results.append(('语料哈希', hash_ok))
    print()

    # 2. Evidence 引句校验
    print('=== 2. Evidence 引句校验 ===')
    with open(base_dir / 'queries.draft.json', 'r', encoding='utf-8') as f:
        queries = json.load(f)

    corpus_texts = {}
    for doc in corpus_manifest['documents']:
        doc_id = doc['docId']
        with open(corpus_dir / f'{doc_id}.md', 'r', encoding='utf-8') as f:
            corpus_texts[doc_id] = f.read()

    evidence_ok = True
    total_evidence = 0
    for query in queries['queries']:
        for ev in query.get('evidence', []) + query.get('nearMissEvidence', []):
            total_evidence += 1
            doc_id = ev['docId']
            quote = ev['quote']
            corpus_text = corpus_texts.get(doc_id, '')
            normalized_corpus = normalize_text(corpus_text)
            normalized_quote = normalize_text(quote)

            if quote in corpus_text or normalized_quote in normalized_corpus:
                pass
            else:
                print(f'  [FAIL] {query["queryId"]}: quote not found in {doc_id}')
                print(f'    quote: {quote[:60]}...')
                evidence_ok = False

    print(f'  总 evidence: {total_evidence}')
    print(f'  [{"PASS" if evidence_ok else "FAIL"}] 全部引句命中语料')
    results.append(('Evidence 引句', evidence_ok))
    print()

    # 3. Chunk 完整性
    print('=== 3. Chunk 完整性 ===')
    chunks = []
    with open(base_dir / 'chunks.jsonl', 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                chunks.append(json.loads(line))

    chunk_ids = [c['chunkId'] for c in chunks]
    unique_ids = set(chunk_ids)
    ffd_total = sum(c['text'].count('\ufffd') for c in chunks)

    chunk_ok = len(chunk_ids) == len(unique_ids) and ffd_total == 0
    print(f'  总 chunks: {len(chunks)}')
    print(f'  chunkId 唯一: {len(unique_ids) == len(chunk_ids)}')
    print(f'  U+FFFD 总数: {ffd_total}')
    print(f'  [{"PASS" if chunk_ok else "FAIL"}] Chunk 完整性')
    results.append(('Chunk 完整性', chunk_ok))
    print()

    # 4. Evidence→Chunk 映射
    print('=== 4. Evidence→Chunk 映射 ===')
    with open(base_dir / 'evidence-chunk-map.json', 'r', encoding='utf-8') as f:
        emap = json.load(f)

    all_chunk_ids = set(chunk_ids)
    mapping_ok = True
    dangling_refs = 0
    unmapped = 0

    for m in emap['mappings']:
        for cid in m.get('mappedChunkIds', []):
            if cid not in all_chunk_ids:
                dangling_refs += 1
                mapping_ok = False
        if m['status'] == 'unmapped':
            unmapped += 1

    print(f'  悬空引用: {dangling_refs}')
    print(f'  未映射: {unmapped}')
    print(f'  [{"PASS" if mapping_ok and unmapped == 0 else "FAIL"}] 映射完整性')
    results.append(('映射完整性', mapping_ok and unmapped == 0))
    print()

    # 5. 重复运行校验（实际执行两次 chunker 并比较）
    print('=== 5. 重复运行校验 ===')
    project_root = base_dir.parent.parent.parent  # eval/datasets/devsupport-v0.1 → project root

    repeatability_ok = False
    try:
        # 保存当前 chunks.jsonl
        current_chunks = (base_dir / 'chunks.jsonl').read_bytes()
        current_hash = sha256_bytes(current_chunks)

        # 确定 Gradle wrapper 命令
        if sys.platform == 'win32':
            gradle_cmd = [str(project_root / 'gradlew.bat')]
        else:
            gradle_cmd = [str(project_root / 'gradlew')]

        # 第一次运行
        print('  运行 #1 ...')
        r1 = subprocess.run(
            gradle_cmd + [':app:evalOfflineChunk', '--no-daemon', '-q'],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=300,
            encoding='utf-8', errors='replace'
        )
        if r1.returncode != 0:
            print(f'  [FAIL] 运行 #1 失败 (exit={r1.returncode})')
            print(f'    stderr: {r1.stderr[:200]}')
        else:
            run1_hash = sha256_file(base_dir / 'chunks.jsonl')

            # 第二次运行
            print('  运行 #2 ...')
            r2 = subprocess.run(
                gradle_cmd + [':app:evalOfflineChunk', '--no-daemon', '-q'],
                cwd=str(project_root),
                capture_output=True, text=True, timeout=300,
                encoding='utf-8', errors='replace'
            )
            if r2.returncode != 0:
                print(f'  [FAIL] 运行 #2 失败 (exit={r2.returncode})')
            else:
                run2_hash = sha256_file(base_dir / 'chunks.jsonl')

                print(f'  运行 #1 SHA-256: {run1_hash[:24]}')
                print(f'  运行 #2 SHA-256: {run2_hash[:24]}')

                if run1_hash == run2_hash:
                    print(f'  [PASS] 两次运行 chunks.jsonl 完全一致')
                    repeatability_ok = True
                else:
                    print(f'  [FAIL] 两次运行 chunks.jsonl 不一致')

                # 恢复原始 chunks.jsonl
                (base_dir / 'chunks.jsonl').write_bytes(current_chunks)
                restored_hash = sha256_file(base_dir / 'chunks.jsonl')
                if restored_hash == current_hash:
                    print(f'  已恢复原始 chunks.jsonl')
                else:
                    print(f'  [WARN] 恢复后哈希不匹配: {restored_hash[:24]} vs {current_hash[:24]}')

    except subprocess.TimeoutExpired:
        print('  [FAIL] 运行超时（300s）')
    except Exception as e:
        print(f'  [FAIL] 异常: {e}')

    results.append(('重复运行校验', repeatability_ok))
    print()

    # 6. Candidate Gold
    print('=== 6. Candidate Gold ===')
    with open(base_dir / 'candidate-gold.json', 'r', encoding='utf-8') as f:
        gold = json.load(f)

    answerable_with_gold = 0
    no_answer_without_gold = 0
    empty_supporting = 0

    for entry in gold['entries']:
        if entry['answerability'] == 'ANSWERABLE':
            cg = entry.get('candidateGold')
            if cg is not None:
                answerable_with_gold += 1
                for ap in cg.get('answerPoints', []):
                    if len(ap.get('supportingChunkIds', [])) == 0:
                        empty_supporting += 1
                        print(f'  [FAIL] {entry["queryId"]} answerPoint#{ap["answerPointIndex"]}: supportingChunkIds 为空')
                all_ids = cg.get('allCandidateChunkIds', [])
                if len(all_ids) == 0:
                    print(f'  [FAIL] {entry["queryId"]}: allCandidateChunkIds 为空')
                    empty_supporting += 1
            else:
                print(f'  [FAIL] {entry["queryId"]}: ANSWERABLE but no gold')
        else:
            if entry.get('candidateGold') is None:
                no_answer_without_gold += 1
            else:
                print(f'  [FAIL] {entry["queryId"]}: NO_ANSWER but has gold')

    gold_ok = (answerable_with_gold == 16 and no_answer_without_gold == 4
               and empty_supporting == 0)
    print(f'  可答题有 gold: {answerable_with_gold}/16')
    print(f'  无答案无 gold: {no_answer_without_gold}/4')
    print(f'  空 supportingChunkIds: {empty_supporting}')
    print(f'  [{"PASS" if gold_ok else "FAIL"}] Candidate Gold 完整性')
    results.append(('Candidate Gold', gold_ok))
    print()

    # 汇总
    print('=== 验证汇总 ===')
    all_pass = all(ok for _, ok in results)
    for name, ok in results:
        status = 'PASS' if ok else 'FAIL'
        print(f'  [{status}] {name}')

    print()
    if all_pass:
        print('所有检查通过。')
        return 0
    else:
        print('存在失败项，请检查。')
        return 1

if __name__ == '__main__':
    sys.exit(main())
