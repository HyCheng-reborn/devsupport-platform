# P1-B 修订报告（v2：Java 生产类复用）

> 状态：**完成，待审核**。未提交 Git，未调用 Embedding/Chat/Rerank，未连接数据库。

## 1. 本轮修订目标

修复第一轮 P1-B 的 4 个问题：
1. `offline_chunker.py` 用 Python tiktoken 模拟 Java TokenTextSplitter，部分 chunk 含 U+FFFD 替换字符
2. `evidence_chunk_mapper.py` 把单 chunk 已包含的证据误标为跨 chunk（31 条跨 chunk，实际只有 1 条需要）
3. `validate_p1b.py` 将确定性检查 SKIP 后仍报告 PASS
4. README 仍写「本轮不切分」，P1B-REPORT 列出未包含在压缩包中的文件

## 2. 完成事项

### 2.1 Java 离线切分工具（Task A）

**文件**：`app/src/main/java/interview/guide/eval/OfflineChunker.java`

**复用生产类**：
- `TextCleaningService.cleanText(String)`：直接 `new TextCleaningService()`，无 Spring 上下文
- `TokenTextSplitter.builder().build()`：与 `KnowledgeBaseVectorService.java:52` 完全一致

**未复用的生产步骤**：
- `DocumentParseService.parseContent(InputStream)`：使用 Tika AutoDetectParser 解析上传文件（PDF/DOCX/TXT）
- **原因**：语料全部为 `.md` 纯文本副本，Tika 对 `.md` 无额外解析价值（等价于直接读文本）
- **明确记录差异**：`chunk-manifest.json` 的 `parsingPolicy.applied = false`，并说明原因

**Gradle 任务**：`app/build.gradle` 新增 `evalOfflineChunk` JavaExec 任务
```bash
./gradlew :app:evalOfflineChunk
```

### 2.2 切分结果（Task B）

**输出文件**：
- `chunks.jsonl`：28 条，每行一个 JSON（chunkId/docId/seq/text/charCount/configId/replacementChars）
- `chunk-manifest.json`：切分配置、清洗策略、解析策略、文档统计

**统计**：
| 文档 | 原始字符 | 清洗后字符 | chunks |
|------|---------|-----------|--------|
| ig-db-migration-readme | 472 | 458 | 1 |
| ig-githooks-readme | 343 | 318 | 1 |
| ig-kb-interview-capacity-tdd | 1859 | 1816 | 2 |
| ig-kb-question-gen-async-tdd | 3165 | 3087 | 3 |
| ig-readme-root | 19800 | 18008 | 12 |
| ig-setup-api-keys | 2541 | 2378 | 2 |
| ig-voice-arch | 10914 | 10367 | 7 |
| **总计** | **39076** | **36432** | **28** |

**验证**：
- U+FFFD 总数：**0**（所有 chunk 无替换字符）
- chunkId 唯一性：**28/28 唯一**
- chunkId 格式：`{docId}__{configId}__{seq:04d}__{sha256(text):12}`
- 评测 chunkId 与生产 VectorStore Document ID（UUID）不同，明确记录在 `evalChunkIdPolicy`

**字符数差异说明**：
- Java `String.length()` 计 UTF-16 code units，Python `len(text)` 计 Unicode codepoints
- 含 supplementary characters（如 emoji）的文档两者不同：ig-setup-api-keys 2541 vs 2535，ig-voice-arch 10914 vs 10902
- 不影响切分结果，仅为计量方法差异

### 2.3 证据映射（Task C）

**文件**：`evidence_chunk_mapper.py`（v2）

**映射逻辑**：
1. 优先单 chunk 完全包含引句（exact match 或 normalized match）
2. 仅当无单 chunk 包含时，检查相邻 chunk 对（跨 chunk）
3. 归一化：CRLF→LF，strip trailing whitespace per line（处理清洗前后的差异）

**结果**：
- 总 evidence：50
- 已映射（单 chunk）：**50**
- 已映射（跨 chunk）：**0**
- 未映射：**0**
- 匹配类型：精确匹配 50，归一化匹配 0

**对比第一轮**：
- 第一轮：31 条跨 chunk（误标）
- 第二轮：0 条跨 chunk（所有引句均被单 chunk 完整包含）

**原因分析**：
- 第一轮用 Python tiktoken 模拟，chunk 边界与 Java 生产类不同
- 第二轮用真实 Java TokenTextSplitter，chunk 边界更合理，短引句均落在单 chunk 内

### 2.4 候选 Gold（Task D）

**文件**：`candidate_gold_builder.py`

**逻辑**：
- 16 道 ANSWERABLE 题：按 `supportsAnswerPoints` 分组，每个 answerPoint 独立列出 supportingChunkIds
- 4 道 NO_ANSWER 题：不给正例 gold，仅记录 nearMissChunks 供参考
- 多证据组合题（11 道）：标记 `multiEvidenceCombinationRequired = true`，需同时命中所有 answerPoint 的 chunk

**统计**：
- 可答题有 gold：16/16
- 无答案无 gold：4/4
- 需多证据组合：11
- 候选 chunk 引用总数：31

**注意**：q01 的 `supportsAnswerPoints` 标注可能不完整（evidence 只标 `[1]`，但引句实际覆盖两个 answerPoint），见待审核事项。

### 2.5 重复运行校验（Task E）

**方法**：
1. 运行 `./gradlew :app:evalOfflineChunk`，保存输出为 run1
2. 再次运行，保存输出为 run2
3. 比较 `chunks.jsonl` 和 `chunk-manifest.json` 的 SHA-256

**结果**：
- `chunks.jsonl`：两次 SHA-256 **完全一致**（`31da4cd0d03c69005d2ef86793ec09e80667e8cc3720598826ed999fdc577f04`）
- `chunk-manifest.json`：结构一致（canonical JSON 匹配），SHA-256 差异仅为 JSON key 排序

**结论**：切分输出**确定性**，相同输入和配置下两次运行内容完全一致。

## 3. 验证结果

运行 `validate_p1b.py`，所有检查通过：

- [PASS] 语料哈希：7 份文档 SHA-256 与 manifest 一致
- [PASS] Evidence 引句：50 条全部逐字命中语料
- [PASS] Chunk 完整性：28 个 chunk 无 U+FFFD，chunkId 唯一
- [PASS] 映射完整性：50 条 evidence 已映射，0 悬空引用
- [PASS] 重复运行校验：chunks.jsonl 两次运行 SHA-256 一致
- [PASS] Candidate Gold：16 道可答题有 gold，4 道无答案题无正例 gold

## 4. 文件清单

```
eval/datasets/devsupport-v0.1/
├── corpus/                          # 7 份文档逐字节副本（未改动）
├── corpus-manifest.json             # 未改动
├── queries.draft.json               # 未改动（50 条 evidence）
├── chunks.jsonl                     # 新增：28 个 chunks（Java 生产类切分）
├── chunk-manifest.json              # 新增：切分配置与统计
├── evidence-chunk-map.json          # 新增：50 条 evidence 映射（0 跨 chunk）
├── candidate-gold.json              # 新增：16 道可答题候选 gold
├── README.md                        # 已更新：反映 P1-B 完成状态
├── P1B-REPORT.md                    # 本文件（重写）
├── evidence_chunk_mapper.py         # 新增：证据映射工具（v2）
├── candidate_gold_builder.py        # 新增：候选 gold 整理工具
└── validate_p1b.py                  # 新增：综合验证脚本（v2）

app/src/main/java/interview/guide/eval/
└── OfflineChunker.java              # 新增：Java 离线切分工具

app/build.gradle
└── evalOfflineChunk task            # 新增：Gradle JavaExec 任务
```

## 5. 与生产代码的对比

| 步骤 | 生产代码 | 离线工具 | 差异 |
|------|---------|---------|------|
| 文本解析 | `DocumentParseService.parseContent()` (Tika) | 直接读 `.md` 文件 | **未复用**：语料为 `.md` 纯文本，Tika 无额外价值 |
| 文本清洗 | `TextCleaningService.cleanText()` | 直接调用同一方法 | **完全一致** |
| 文本切分 | `TokenTextSplitter.builder().build()` | 直接调用同一构造 | **完全一致** |
| 向量化 | `VectorStore.add()` | 未执行 | **不涉及**：本轮只做离线切分 |

## 6. 待审核事项

- [ ] 是否接受跳过 Tika 解析（语料为 `.md` 纯文本）
- [ ] Java `String.length()` vs Python `len(text)` 的字符数差异是否可接受
- [ ] q01 的 `supportsAnswerPoints` 标注是否应改为 `[1, 2]`（当前为 `[1]`）
- [ ] 0 条跨 chunk 映射是否符合预期（所有引句均被单 chunk 完整包含）
- [ ] 是否需要为长文档按标题做章节级切分，以提升检索区分度

## 7. 统计摘要

| 指标 | 数值 |
|------|------|
| 语料文档 | 7 份 |
| 语料字符数（Python） | 39,076 |
| 语料字符数（Java） | 39,094 |
| 清洗后字符数 | 36,432 |
| 切分 chunks | 28 |
| U+FFFD 总数 | 0 |
| Evidence 总数 | 50 |
| 已映射 evidence | 50 (100%) |
| 跨 chunk evidence | 0 (0%) |
| 可答题 | 16 |
| 无答案题 | 4 |
| 需多证据组合 | 11 |

## 8. 下一步

- 等待审核
- 审核通过后，可进入 P1-C（真实检索评测）或 P2（Hybrid 检索实现）

---

**执行命令记录**：
```bash
# 编译
./gradlew :app:compileJava

# 运行离线切分
./gradlew :app:evalOfflineChunk

# 运行证据映射
cd eval/datasets/devsupport-v0.1
python evidence_chunk_mapper.py

# 运行候选 gold 整理
python candidate_gold_builder.py

# 运行综合验证
python validate_p1b.py
```

**退出码**：所有命令退出码均为 0（成功）。
