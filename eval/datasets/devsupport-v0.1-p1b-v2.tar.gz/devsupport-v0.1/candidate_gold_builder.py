#!/usr/bin/env python3
"""
P1-B candidate gold builder.

For each ANSWERABLE query:
  - Group evidence by supportsAnswerPoints
  - For each answer point, list chunkIds that directly support it
  - Mark multi-evidence combination relationships
  - Do NOT union all mappedChunkIds into "any hit is correct"

For NO_ANSWER queries:
  - No positive gold
  - Record nearMissEvidence chunkIds for reference only
"""

import json
import sys
from pathlib import Path
from collections import defaultdict

def main():
    sys.stdout.reconfigure(encoding='utf-8')
    base_dir = Path(__file__).parent

    with open(base_dir / 'evidence-chunk-map.json', 'r', encoding='utf-8') as f:
        emap = json.load(f)

    with open(base_dir / 'queries.draft.json', 'r', encoding='utf-8') as f:
        queries_data = json.load(f)

    # Build evidence lookup: (queryId, evidenceIndex) -> mapping
    ev_lookup = {}
    for m in emap['mappings']:
        key = (m['queryId'], m['evidenceIndex'])
        ev_lookup[key] = m

    gold_entries = []

    for query in queries_data['queries']:
        qid = query['queryId']
        answerability = query['answerability']
        question = query['question']
        question_type = query['questionType']
        answer_points = query.get('expectedAnswerPoints', [])

        entry = {
            'queryId': qid,
            'question': question,
            'questionType': question_type,
            'answerability': answerability,
        }

        if answerability == 'NO_ANSWER':
            entry['candidateGold'] = None
            entry['reason'] = 'NO_ANSWER: 语料不包含答案'
            entry['missingFromCorpus'] = query.get('missingFromCorpus', '')
            entry['answerSourceOutsideCorpus'] = query.get('answerSourceOutsideCorpus', '')

            near_miss_chunks = []
            for ev_idx, ev in enumerate(query.get('nearMissEvidence', [])):
                m = ev_lookup.get((qid, ev_idx))
                if m and m['mappedChunkIds']:
                    near_miss_chunks.append({
                        'evidenceIndex': ev_idx,
                        'quote': ev['quote'],
                        'mappedChunkIds': m['mappedChunkIds'],
                        'note': 'nearMiss - 语料仅定性提及相关主题，不包含完整答案'
                    })
            if near_miss_chunks:
                entry['nearMissChunks'] = near_miss_chunks
        else:
            # ANSWERABLE: build candidate gold per answer point
            evidence_list = query.get('evidence', [])

            # Group evidence by answer point
            point_to_chunks = defaultdict(list)
            point_to_evidence = defaultdict(list)

            for ev_idx, ev in enumerate(evidence_list):
                m = ev_lookup.get((qid, ev_idx))
                if not m:
                    continue

                supported_points = ev.get('supportsAnswerPoints', [])
                chunk_ids = m.get('mappedChunkIds', [])

                for pt in supported_points:
                    for cid in chunk_ids:
                        if cid not in point_to_chunks[pt]:
                            point_to_chunks[pt].append(cid)
                    point_to_evidence[pt].append({
                        'evidenceIndex': ev_idx,
                        'docId': ev['docId'],
                        'quote': ev['quote'],
                        'chunkIds': chunk_ids,
                        'crossChunk': m.get('crossChunk', False),
                        'matchType': m.get('matchType'),
                    })

            # Build per-point gold
            answer_point_gold = []
            for pt_idx, pt_text in enumerate(answer_points, 1):
                pt_key = pt_idx
                gold_point = {
                    'answerPointIndex': pt_idx,
                    'answerPointText': pt_text,
                    'supportingChunkIds': point_to_chunks.get(pt_key, []),
                    'supportingEvidenceCount': len(point_to_evidence.get(pt_key, [])),
                    'evidenceDetails': point_to_evidence.get(pt_key, []),
                }
                answer_point_gold.append(gold_point)

            # Determine if multi-evidence combination is needed
            multi_evidence_needed = len(answer_points) > 1

            entry['candidateGold'] = {
                'answerPoints': answer_point_gold,
                'multiEvidenceCombinationRequired': multi_evidence_needed,
                'combinationNote': (
                    '需要同时命中所有 answerPoint 的 chunk 才算完整回答'
                    if multi_evidence_needed
                    else '单个 answerPoint，命中对应 chunk 即可'
                ),
                'allCandidateChunkIds': sorted(set(
                    cid
                    for pt in answer_point_gold
                    for cid in pt['supportingChunkIds']
                )),
            }

        gold_entries.append(entry)

    # Summary statistics
    answerable_count = sum(1 for e in gold_entries if e['answerability'] == 'ANSWERABLE')
    no_answer_count = sum(1 for e in gold_entries if e['answerability'] == 'NO_ANSWER')
    multi_evidence_count = sum(
        1 for e in gold_entries
        if e.get('candidateGold') and e['candidateGold'].get('multiEvidenceCombinationRequired')
    )
    total_candidate_chunks = sum(
        len(e.get('candidateGold', {}).get('allCandidateChunkIds', []))
        for e in gold_entries
        if e.get('candidateGold')
    )

    output = {
        'goldPolicy': {
            'answerableRule': '每个 answerPoint 独立列出 supportingChunkIds；多要点题需组合命中，不可并集后"任意一个命中即答对"',
            'noAnswerRule': 'NO_ANSWER 题不给正例 gold；仅记录 nearMiss 的 chunk 引用供参考',
            'chunkIdSource': 'evidence→chunk 映射结果（evidence-chunk-map.json）',
        },
        'statistics': {
            'totalQueries': len(gold_entries),
            'answerableQueries': answerable_count,
            'noAnswerQueries': no_answer_count,
            'multiEvidenceQueries': multi_evidence_count,
            'totalCandidateChunkReferences': total_candidate_chunks,
        },
        'entries': gold_entries,
    }

    output_file = base_dir / 'candidate-gold.json'
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print(f'已写入: {output_file}')
    print()
    print('=== 候选 Gold 统计 ===')
    print(f'总查询: {len(gold_entries)}')
    print(f'  可答题: {answerable_count}')
    print(f'  无答案: {no_answer_count}')
    print(f'需多证据组合: {multi_evidence_count}')
    print(f'候选 chunk 引用总数: {total_candidate_chunks}')

    # Per-query summary
    print()
    for e in gold_entries:
        qid = e['queryId']
        ans = e['answerability']
        if ans == 'ANSWERABLE':
            gold = e['candidateGold']
            n_points = len(gold['answerPoints'])
            n_chunks = len(gold['allCandidateChunkIds'])
            multi = 'MULTI' if gold['multiEvidenceCombinationRequired'] else 'SINGLE'
            print(f'{qid} | {ans:10s} | {multi:6s} | points={n_points} chunks={n_chunks} | {e["question"][:40]}')
        else:
            nm = len(e.get('nearMissChunks', []))
            print(f'{qid} | {ans:10s} | NO_GOLD | nearMiss={nm} | {e["question"][:40]}')

if __name__ == '__main__':
    main()
