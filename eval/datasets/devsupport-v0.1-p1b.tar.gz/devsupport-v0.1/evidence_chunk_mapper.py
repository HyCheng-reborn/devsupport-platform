#!/usr/bin/env python3
"""
Evidence→Chunk 映射工具
基于文本匹配建立 evidence 引句到 chunk 的映射
不编造 chunkId，只做真实匹配
"""

import json
from pathlib import Path
from typing import List, Dict, Any, Optional

SCRIPT_DIR = Path(__file__).parent

def load_chunks() -> List[Dict[str, Any]]:
    """加载 chunks.jsonl"""
    chunks_file = SCRIPT_DIR / "chunks.jsonl"
    chunks = []
    with open(chunks_file, 'r', encoding='utf-8') as f:
        for line in f:
            chunks.append(json.loads(line))
    return chunks

def load_queries() -> Dict[str, Any]:
    """加载 queries.draft.json"""
    queries_file = SCRIPT_DIR / "queries.draft.json"
    with open(queries_file, 'r', encoding='utf-8') as f:
        return json.load(f)

def find_chunk_for_quote(quote: str, doc_id: str, chunks: List[Dict[str, Any]]) -> List[str]:
    """
    在指定文档的 chunks 中查找包含引句的 chunk
    返回匹配的 chunkId 列表（可能跨多个 chunk）
    """
    matching_chunks = []

    # 先找出该文档的所有 chunks
    doc_chunks = [c for c in chunks if c['docId'] == doc_id]

    for i, chunk in enumerate(doc_chunks):
        chunk_text = chunk['text']

        # 精确匹配：引句完全包含在 chunk 中
        if quote in chunk_text:
            matching_chunks.append(chunk['chunkId'])
            continue

        # 跨 chunk 情况：检查相邻 chunks 的组合
        # 检查当前 chunk 和下一个 chunk 的组合
        if i + 1 < len(doc_chunks):
            next_chunk = doc_chunks[i + 1]
            combined = chunk_text + next_chunk['text']
            if quote in combined:
                matching_chunks.append(chunk['chunkId'])
                matching_chunks.append(next_chunk['chunkId'])
                continue

        # 检查当前 chunk 和前一个 chunk 的组合（避免重复添加）
        if i > 0 and not matching_chunks:
            prev_chunk = doc_chunks[i - 1]
            combined = prev_chunk['text'] + chunk_text
            if quote in combined:
                if prev_chunk['chunkId'] not in matching_chunks:
                    matching_chunks.append(prev_chunk['chunkId'])
                matching_chunks.append(chunk['chunkId'])

    # 去重并保持顺序
    seen = set()
    unique_chunks = []
    for cid in matching_chunks:
        if cid not in seen:
            seen.add(cid)
            unique_chunks.append(cid)

    return unique_chunks

def build_evidence_chunk_map():
    """建立 evidence→chunk 映射"""
    print("=== Evidence→Chunk 映射工具 ===")
    print()

    chunks = load_chunks()
    queries_data = load_queries()

    print(f"加载 {len(chunks)} 个 chunks")
    print(f"加载 {len(queries_data['queries'])} 个 queries")
    print()

    mappings = []
    stats = {
        "totalEvidence": 0,
        "mapped": 0,
        "unmapped": 0,
        "crossChunk": 0,
        "ambiguous": 0
    }

    for query in queries_data['queries']:
        query_id = query['queryId']

        # 处理 evidence
        for ev in query.get('evidence', []):
            stats['totalEvidence'] += 1
            quote = ev['quote']
            doc_id = ev['docId']
            supports_points = ev.get('supportsAnswerPoints', [])

            matching_chunk_ids = find_chunk_for_quote(quote, doc_id, chunks)

            mapping = {
                "queryId": query_id,
                "evidenceType": "evidence",
                "docId": doc_id,
                "quote": quote,
                "quotePreview": quote[:50] + "..." if len(quote) > 50 else quote,
                "locator": ev.get('locator', {}),
                "supportsAnswerPoints": supports_points,
                "mappedChunkIds": matching_chunk_ids,
                "mappingStatus": "mapped" if matching_chunk_ids else "unmapped",
                "isCrossChunk": len(matching_chunk_ids) > 1,
                "notes": []
            }

            if not matching_chunk_ids:
                stats['unmapped'] += 1
                mapping['notes'].append("引句未在任何 chunk 中找到，可能是切分导致")
            else:
                stats['mapped'] += 1
                if len(matching_chunk_ids) > 1:
                    stats['crossChunk'] += 1
                    mapping['notes'].append(f"引句跨越 {len(matching_chunk_ids)} 个 chunks")

            mappings.append(mapping)

        # 处理 nearMissEvidence
        for ev in query.get('nearMissEvidence', []):
            stats['totalEvidence'] += 1
            quote = ev['quote']
            doc_id = ev['docId']
            supports_points = ev.get('supportsAnswerPoints', [])

            matching_chunk_ids = find_chunk_for_quote(quote, doc_id, chunks)

            mapping = {
                "queryId": query_id,
                "evidenceType": "nearMissEvidence",
                "docId": doc_id,
                "quote": quote,
                "quotePreview": quote[:50] + "..." if len(quote) > 50 else quote,
                "locator": ev.get('locator', {}),
                "supportsAnswerPoints": supports_points,
                "mappedChunkIds": matching_chunk_ids,
                "mappingStatus": "mapped" if matching_chunk_ids else "unmapped",
                "isCrossChunk": len(matching_chunk_ids) > 1,
                "notes": []
            }

            if not matching_chunk_ids:
                stats['unmapped'] += 1
                mapping['notes'].append("nearMiss 引句未在任何 chunk 中找到")
            else:
                stats['mapped'] += 1
                if len(matching_chunk_ids) > 1:
                    stats['crossChunk'] += 1
                    mapping['notes'].append(f"nearMiss 引句跨越 {len(matching_chunk_ids)} 个 chunks")

            mappings.append(mapping)

    # 输出映射文件
    output = {
        "datasetId": "devsupport",
        "version": "v0.1",
        "mappingMethod": "text-based exact match (quote in chunk text)",
        "crossChunkHandling": "若引句跨越多个 chunk，记录所有相关 chunkId",
        "unmappedHandling": "若引句未找到匹配，标记为 unmapped 并记录原因",
        "statistics": stats,
        "mappings": mappings
    }

    output_file = SCRIPT_DIR / "evidence-chunk-map.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print(f"已写入: {output_file}")
    print()
    print("=== 映射统计 ===")
    print(f"总 evidence 项: {stats['totalEvidence']}")
    print(f"已映射: {stats['mapped']}")
    print(f"未映射: {stats['unmapped']}")
    print(f"跨 chunk: {stats['crossChunk']}")
    print()

    if stats['unmapped'] > 0:
        print("[!] 存在未映射的 evidence，请检查:")
        for m in mappings:
            if m['mappingStatus'] == 'unmapped':
                print(f"  - {m['queryId']} [{m['docId']}]: {m['quotePreview']}")
    else:
        print("[OK] 所有 evidence 均已映射到 chunk")

if __name__ == "__main__":
    build_evidence_chunk_map()
