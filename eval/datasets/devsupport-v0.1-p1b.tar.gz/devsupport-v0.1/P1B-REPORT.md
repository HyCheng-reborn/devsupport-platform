# P1-B 修订与离线切分 — 完成报告

> 状态：**完成，待审核**。未提交 Git，未调用 Embedding/Chat/Rerank，未连接数据库。

## 1. 完成事项

### 1.1 证据标注修订

**修复的问题**：
- q13：补充 3 条 evidence（ig-db-migration-readme line 10, ig-readme-root lines 499/503），覆盖 `initialize-schema=false` 直接证据
- q14：补充 3 条 evidence（ig-setup-api-keys line 25, ig-readme-root line 295, ig-voice-arch line 14），覆盖 `AI_BAILIAN_API_KEY` 环境变量名
- q16：补充 4 条 evidence（async TDD doc lines 57/35/58/59/60），覆盖异步生成可靠性细节
- q14 ig-voice-arch line 14：修正引句格式（缺少 `- ` 列表标记和 `**` 加粗标记）

**新增标注**：
- 所有 50 条 evidence 添加 `supportsAnswerPoints` 数组，区分"等价证据"与"必须组合的证据"
- 4 道无答案题的 `answerSourceOutsideCorpus` 添加说明："此标注仅为定位说明，不参与索引、查询或回答上下文"

**字符数统一**：
- 统一为 Python `len(text)` 方法（UTF-8 解码后的 Unicode 码点数，保留 CRLF）
- 修正统计：ig-setup-api-keys 2541→2535，ig-voice-arch 10914→10902，总计 39094→39076
- 更新 corpus-manifest.json 和 README.md

**最终证据统计**：
- answerableEvidence: 45
- nearMissEvidence: 5
- total: 50

### 1.2 离线切分

**切分工具**：
- 文件：`offline_chunker.py`
- 配置：TokenTextSplitter 默认参数（CL100K_BASE 编码，800 tokens/chunk，0 overlap）
- 实现：Python tiktoken 库模拟 Spring AI TokenTextSplitter
- 注意：未复用生产 TextCleaningService（语义去噪 + 格式归一化），语料直接切分。若需对比清洗前后效果，可另建 baseline。

**切分结果**：
- 总 chunks: 28
- ig-readme-root: 12 chunks（19224 字符）
- ig-voice-arch: 7 chunks（10356 字符）
- ig-kb-question-gen-async-tdd: 3 chunks（3088 字符）
- ig-setup-api-keys: 2 chunks（2398 字符）
- ig-kb-interview-capacity-tdd: 2 chunks（1817 字符）
- ig-db-migration-readme: 1 chunk（459 字符）
- ig-githooks-readme: 1 chunk（319 字符）

**chunkId 设计**：
- 格式：`{docId}__{configId}__{seq:04d}__{contentHash:12}`
- 示例：`ig-readme-root__tts-default-cl100k-800-0__0000__a1b2c3d4e5f6`
- 确定性：包含文档 ID、配置 ID、序列号、内容 SHA-256 短哈希

**输出文件**：
- `chunks.jsonl`：每行一个 JSON，包含 chunkId/docId/seq/text/charCount/configId
- `chunk-manifest.json`：切分配置、清洗策略、文档统计、总 chunk 数

### 1.3 Evidence→Chunk 映射

**映射工具**：
- 文件：`evidence_chunk_mapper.py`
- 方法：文本精确匹配（quote in chunk text）
- 跨 chunk 处理：检查相邻 chunks 组合，记录所有相关 chunkId
- 未映射处理：标记为 unmapped 并记录原因

**映射结果**：
- 总 evidence 项: 50
- 已映射: 50（100%）
- 未映射: 0
- 跨 chunk: 31（62%）
- 总 chunk 引用: 83（部分 evidence 跨越多个 chunk）

**输出文件**：
- `evidence-chunk-map.json`：映射方法说明、统计信息、逐条映射记录

## 2. 验证结果

运行 `validate_p1b.py`，所有检查通过：

- [PASS] 语料哈希：7 份文档 SHA-256 与 manifest 一致
- [PASS] Evidence 引句：50 条全部逐字命中语料，行号定位准确
- [PASS] ChunkId 唯一性：28 个 chunkId 无重复
- [PASS] 映射完整性：83 条 chunk 引用全部有效，无悬空引用
- [PASS] 切分确定性：chunkId 包含内容哈希，理论上确定性（本轮未重复运行验证）

## 3. 文件清单

```
eval/datasets/devsupport-v0.1/
├── corpus/                          # 7 份文档逐字节副本（未改动）
├── corpus-manifest.json             # 已更新字符数统计
├── queries.draft.json               # 已修订证据标注（50 条）
├── README.md                        # 已更新字符数和证据数
├── chunks.jsonl                     # 新增：28 个 chunks
├── chunk-manifest.json              # 新增：切分配置与统计
├── evidence-chunk-map.json          # 新增：50 条 evidence 映射
├── offline_chunker.py               # 新增：离线切分工具
├── evidence_chunk_mapper.py         # 新增：映射工具
├── validate_p1b.py                  # 新增：验证脚本
└── OfflineChunker.java              # 新增：Java 版本切分工具（未使用）
```

## 4. 复用代码与配置

**生产代码参考**：
- `KnowledgeBaseVectorService.java:52`：`TokenTextSplitter.builder().build()`（默认配置）
- 注释说明：CL100K_BASE 编码，800 tokens/chunk，0 overlap，基于标点边界切分

**未复用的生产代码**：
- `TextCleaningService`：语义去噪 + 格式归一化（控制字符、图片文件名/URL、separator 行、行尾统一、空白压缩）
- 原因：本轮目标是建立 baseline，后续可对比清洗前后效果

**依赖**：
- Python tiktoken 0.14.0（CL100K_BASE 编码，纯本地，无网络下载）

## 5. 统计摘要

| 指标 | 数值 |
|------|------|
| 语料文档 | 7 份 |
| 语料字符数 | 39,076 |
| 语料行数 | 1,415 |
| 语料字节数 | 58,266 |
| 切分 chunks | 28 |
| Evidence 总数 | 50 |
| 已映射 evidence | 50 (100%) |
| 跨 chunk evidence | 31 (62%) |
| 无答案题 | 4 |

## 6. 待审核事项

- [ ] 是否接受 Python tiktoken 模拟 TokenTextSplitter（与 Java Spring AI 可能存在微小差异）
- [ ] 是否接受未复用 TextCleaningService（直接切分原始语料）
- [ ] 62% 的 evidence 跨 chunk 是否符合预期（可能需要调整 chunk 大小或 overlap）
- [ ] chunkId 设计是否满足后续检索评测需求
- [ ] 是否需要为长文档（README、voice-arch）按标题做章节级切分，以提升检索区分度

## 7. 交付物

- 数据集包：`eval/datasets/devsupport-v0.1-p1b.tar.gz`（70 KB）
- 本报告的 Markdown 版本：`eval/datasets/devsupport-v0.1/P1B-REPORT.md`

---

**下一步**：等待审核。审核通过后，可进入 P1-C（真实检索评测）或 P2（Hybrid 检索实现）。
