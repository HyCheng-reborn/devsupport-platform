#!/usr/bin/env python3
"""
离线语料切分工具
复用生产 TokenTextSplitter 默认配置（CL100K_BASE, 800 tokens, 0 overlap）
不调用 Embedding/Chat/Rerank，不连接数据库，不启动 Spring 上下文

注意：本脚本使用 Python tiktoken 库模拟 Spring AI TokenTextSplitter 行为。
若需完全一致的字节级结果，应使用 Java 版本直接调用 Spring AI 库。
"""

import json
import hashlib
import os
from pathlib import Path
from typing import List, Dict, Any

try:
    import tiktoken
except ImportError:
    print("错误: 需要安装 tiktoken 库")
    print("运行: pip install tiktoken")
    exit(1)

# 使用脚本所在目录作为基准
SCRIPT_DIR = Path(__file__).parent
CORPUS_DIR = SCRIPT_DIR / "corpus"
OUTPUT_DIR = SCRIPT_DIR
CONFIG_ID = "tts-default-cl100k-800-0"

# TokenTextSplitter 默认参数
DEFAULT_CHUNK_SIZE = 800
DEFAULT_OVERLAP = 0
DEFAULT_MIN_CHUNK_SIZE_CHARS = 350
DEFAULT_MIN_CHUNK_LENGTH_TO_EMBED = 5
DEFAULT_MAX_NUM_CHUNKS = 10000
DEFAULT_KEEP_SEPARATOR = True
DEFAULT_PUNCTUATION_MARKS = ". ? ! \n"
DEFAULT_ENCODING = "cl100k_base"


def sha256_short(text: str) -> str:
    """生成文本的 SHA-256 短哈希（前 12 位）"""
    return hashlib.sha256(text.encode('utf-8')).hexdigest()[:12]


def generate_chunk_id(doc_id: str, config_id: str, seq: int, text: str) -> str:
    """生成确定性 chunkId: docId__configId__seq__contentHash"""
    content_hash = sha256_short(text)
    return f"{doc_id}__{config_id}__{seq:04d}__{content_hash}"


def split_by_tokens(text: str, chunk_size: int = DEFAULT_CHUNK_SIZE,
                    overlap: int = DEFAULT_OVERLAP,
                    encoding_name: str = DEFAULT_ENCODING) -> List[str]:
    """
    使用 tiktoken 按 token 数切分文本
    模拟 TokenTextSplitter 的核心逻辑
    """
    enc = tiktoken.get_encoding(encoding_name)
    tokens = enc.encode(text)

    chunks = []
    start = 0

    while start < len(tokens):
        end = start + chunk_size
        chunk_tokens = tokens[start:end]
        chunk_text = enc.decode(chunk_tokens)
        chunks.append(chunk_text)

        if overlap > 0:
            start = end - overlap
        else:
            start = end

    return chunks


def refine_chunks_by_sentences(chunks: List[str],
                                min_chunk_size_chars: int = DEFAULT_MIN_CHUNK_SIZE_CHARS,
                                punctuation_marks: str = DEFAULT_PUNCTUATION_MARKS) -> List[str]:
    """
    在 token 切分基础上，按标点边界微调
    模拟 TokenTextSplitter 的 keepSeparator 和标点边界逻辑
    """
    refined = []

    for chunk in chunks:
        if len(chunk) < min_chunk_size_chars:
            # 太短的 chunk 暂时保留，后续合并
            refined.append(chunk)
            continue

        # 尝试在标点处截断
        last_punct_pos = -1
        for i, char in enumerate(chunk):
            if char in punctuation_marks:
                last_punct_pos = i

        if last_punct_pos > min_chunk_size_chars // 2:
            # 在标点处截断
            refined.append(chunk[:last_punct_pos + 1])
            remaining = chunk[last_punct_pos + 1:]
            if len(remaining) >= DEFAULT_MIN_CHUNK_LENGTH_TO_EMBED:
                refined.append(remaining)
        else:
            refined.append(chunk)

    return refined


def chunk_document(doc_id: str, content: str) -> List[Dict[str, Any]]:
    """对单个文档进行切分"""
    # 使用纯 token 切分，不做标点边界微调（避免数据丢失）
    raw_chunks = split_by_tokens(content, DEFAULT_CHUNK_SIZE, DEFAULT_OVERLAP)

    # 过滤太短的 chunk
    final_chunks = [c for c in raw_chunks if len(c) >= DEFAULT_MIN_CHUNK_LENGTH_TO_EMBED]

    # 限制最大 chunk 数
    if len(final_chunks) > DEFAULT_MAX_NUM_CHUNKS:
        final_chunks = final_chunks[:DEFAULT_MAX_NUM_CHUNKS]

    # 生成 chunk 记录
    chunk_records = []
    for seq, chunk_text in enumerate(final_chunks):
        chunk_id = generate_chunk_id(doc_id, CONFIG_ID, seq, chunk_text)
        chunk_records.append({
            "chunkId": chunk_id,
            "docId": doc_id,
            "seq": seq,
            "text": chunk_text,
            "charCount": len(chunk_text),
            "configId": CONFIG_ID
        })

    return chunk_records


def main():
    print("=== 离线语料切分工具 ===")
    print(f"配置: TokenTextSplitter 默认参数 (CL100K_BASE, {DEFAULT_CHUNK_SIZE} tokens, {DEFAULT_OVERLAP} overlap)")
    print(f"注意: 使用 Python tiktoken 模拟，与 Java Spring AI 可能存在微小差异")
    print()

    all_chunks = []
    doc_stats = []

    # 读取所有语料文件
    corpus_files = sorted(CORPUS_DIR.glob("*.md"))

    for file in corpus_files:
        doc_id = file.stem
        content = file.read_text(encoding='utf-8')

        print(f"处理文档: {doc_id} ({len(content)} 字符)")

        chunks = chunk_document(doc_id, content)

        print(f"  切分为 {len(chunks)} 个 chunks")

        all_chunks.extend(chunks)

        doc_stats.append({
            "docId": doc_id,
            "chunkCount": len(chunks),
            "totalChars": len(content)
        })

    # 构建 manifest
    manifest = {
        "datasetId": "devsupport",
        "version": "v0.1",
        "chunkerConfig": {
            "splitter": "TokenTextSplitter (Python tiktoken 模拟)",
            "configId": CONFIG_ID,
            "encoding": DEFAULT_ENCODING,
            "chunkSize": DEFAULT_CHUNK_SIZE,
            "overlap": DEFAULT_OVERLAP,
            "minChunkSizeChars": DEFAULT_MIN_CHUNK_SIZE_CHARS,
            "minChunkLengthToEmbed": DEFAULT_MIN_CHUNK_LENGTH_TO_EMBED,
            "maxNumChunks": DEFAULT_MAX_NUM_CHUNKS,
            "keepSeparator": DEFAULT_KEEP_SEPARATOR,
            "punctuationMarks": DEFAULT_PUNCTUATION_MARKS,
            "note": "模拟 Spring AI TokenTextSplitter 默认配置。若需字节级一致，应使用 Java 版本。"
        },
        "cleaningPolicy": {
            "applied": False,
            "note": "本轮未复用生产 TextCleaningService（语义去噪 + 格式归一化），语料直接切分。若后续需要对比清洗前后效果，可另建 baseline。"
        },
        "documentStats": doc_stats,
        "totalChunks": len(all_chunks)
    }

    # 写入 chunks.jsonl
    chunks_file = OUTPUT_DIR / "chunks.jsonl"
    with open(chunks_file, 'w', encoding='utf-8') as f:
        for chunk in all_chunks:
            f.write(json.dumps(chunk, ensure_ascii=False) + '\n')

    print(f"\n已写入: {chunks_file} ({len(all_chunks)} 条)")

    # 写入 chunk-manifest.json
    manifest_file = OUTPUT_DIR / "chunk-manifest.json"
    with open(manifest_file, 'w', encoding='utf-8') as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    print(f"已写入: {manifest_file}")

    print(f"\n=== 切分完成 ===")
    print(f"总 chunks: {len(all_chunks)}")
    print("下一步: 运行 evidence_chunk_mapper.py 建立 evidence→chunk 映射")


if __name__ == "__main__":
    main()
