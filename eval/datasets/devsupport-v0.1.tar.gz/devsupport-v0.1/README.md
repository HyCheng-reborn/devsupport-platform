# devsupport-v0.1 — 研发项目知识助手检索评测「开发集草案」

> 状态：**draft（开发集草案）**。**不是独立测试集**，不作为最终评测基线。
> 本轮**只准备资料**：未调用 Embedding / Chat / Rerank，未启动应用或基础设施，未上传入库，未改生产代码，未实现 Hybrid。

## 1. 目的

为「研发项目知识助手」（文档理解、配置/接口查询、故障排查）准备一批**真实文档语料**与**问题草案**，供后续离线检索评测（P1-A 指标核心已就绪）在真实语料上做开发迭代。

## 2. 来源与冻结信息

- 仓库：InterviewGuide（当前工作区）。
- 快照提交 `snapshotCommit`：`d2fd5e633248b2c008cf387ab82651a56cca8502`（P1-A 提交后的 HEAD）。
- 每份文档另记 `sourceCommit`（该文件最近一次改动提交，`git log -1`）。
- 源许可证：AGPL-3.0（见根 README「许可证」）。
- 语料为仓库文档的**逐字节副本**（`cp`，未改写、未删节、未重排）。已用 sha256 校验副本与原文件一致。

## 3. 准备方式

1. 从仓库中筛选与「启动/部署、配置/数据库/Redis/对象存储、文档上传与知识库使用、项目结构与故障排查」相关的**真实文档**，优先 README、部署说明与业务技术文档。
2. 整文件复制到 `corpus/`，文件名使用稳定 `docId`（`excerptMode=whole-file`，故 `excerptSha256 == originalSha256`）。
3. 在 `corpus-manifest.json` 记录 docId、原始路径、来源提交、原文件与节选 sha256、节选范围、行/字符数、主题。
4. 在 `queries.draft.json` 出 20 道题，每题带稳定 queryId、question、answerability、题型；可答题给出 evidence（docId + **原文引句** + 章节 + 行号）与预期答案要点。
5. 已用脚本校验：JSON 合法；**39 条 evidence 引句全部逐字命中语料**；**全部行号定位准确**；题型分布与 answerability 分布符合约定。

### 明确排除（不作为语料）

- `.env` / `.env.example`（密钥占位与配置）、日志、个人资料、构建产物、缓存。
- `AGENTS.md`、`CLAUDE.md`、`.claude/rules/*.md`（**Agent 操作指令**，非产品知识）。
- `frontend/README.md`（Vite 官方模板样板文，无项目专有内容）。
- `app/src/main/resources/skills/**`（面试题库/技能参考，非本项目研发文档）。
- `interview-guide_本机环境与启动关闭说明.md`（本机环境说明，未跟踪）。

## 4. 语料清单（7 份，合计 39094 字符 / 1415 行 / 58266 字节）

| docId | 原始路径 | 主题覆盖 | 字符 | sourceCommit |
| --- | --- | --- | --- | --- |
| ig-readme-root | README.md | 启动/部署、配置、DB、Redis、对象存储、知识库、结构、FAQ | 19800 | 7ee0ff2 |
| ig-voice-arch | docs/voice-interview-architecture.md | 架构、配置、部署、API、语音、FAQ | 10914 | 28e97a3 |
| ig-db-migration-readme | app/src/main/resources/db/migration/README.md | 数据库、Flyway、配置 | 472 | f42f750 |
| ig-setup-api-keys | SETUP_API_KEYS.md | 密钥配置、语音模型、验证、FAQ（仅占位密钥，无真实密钥） | 2541 | 28e97a3 |
| ig-githooks-readme | .githooks/README.md | 开发流程、提交规范、命令 | 343 | f42f750 |
| ig-kb-question-gen-async-tdd | .claude/tdd/knowledge-base-question-generation-async.tdd.md | 知识库题目异步生成可靠性 | 3165 | a63bb34 |
| ig-kb-interview-capacity-tdd | .claude/tdd/knowledge-base-interview-capacity.tdd.md | 知识库面试严格追问容量、错误码 | 1859 | 0b99aaa |

> 关于两份 `.claude/tdd/*.md`：它们是**工程/TDD 证据文档**（描述功能行为、状态机、错误码与测试保证），**不是 Agent 操作指令**，故纳入产品知识语料；被排除的是 `AGENTS.md` 与 `.claude/rules/*`。若评审认为整个 `.claude/**` 都应排除，则语料降到 5 份（<6），需另选替代来源——见「待审核事项」。

## 5. 问题草案（20 道）

- 题型分布：精确查找 6 / 自然语言改述 6 / 多证据组合 4 / 无答案 4。
- answerability：ANSWERABLE 16 / NO_ANSWER 4。
- 标注原则：
  - **预期答案只能来自选定语料**，不用模型常识补全。
  - **不编造 chunkId**：本轮不切分，evidence 以 docId + 原文引句 + 行号定位；真实切分后再建立 evidence→chunk 映射。
  - 无答案题遵循「不把‘暂时没找到’当无答案」：每题写明语料**缺少什么**（`missingFromCorpus`）并指出真实答案位于语料之外的何处（`answerSourceOutsideCorpus`）。

### 无答案题依据（已核对源码，确认真实答案在语料之外）

| queryId | 问题要点 | 语料缺失 | 真实答案所在（非语料） |
| --- | --- | --- | --- |
| q17 | RAG 相似度阈值默认值与配置项名 | 阈值/TopK 具体数值与键名 | `application.yml`：`APP_AI_RAG_TOPK_SHORT/MEDIUM/LONG` 默认 20/12/8；阈值需查检索源码 |
| q18 | 向量化 chunk 大小与 overlap | chunk/overlap 数值 | `KnowledgeBaseVectorService.java:51`（TokenTextSplitter 默认，约 800 tokens、无重叠） |
| q19 | MinIO createbuckets 具体命令与访问策略 | 初始化脚本内容 | `docker-compose.yml:102-116`（`mc mb` / `mc anonymous set public`） |
| q20 | 语音 WS 各消息类型完整字段结构 | payload 字段定义 | 源码 `VoiceInterviewWebSocketHandler` 与前端 WS 类型定义 |

## 6. 文档与源码不一致 / 需人工确认（未擅自改原文）

1. **前端指南引用失配（较明确）**：`ig-voice-arch` 第 546 行「相关文档」把 `../frontend/README.md` 标为「前端开发指南」，但该文件实际是 **Vite 官方模板样板文**（React+TypeScript+Vite 通用说明），**无任何项目专有前端指导**。→ 已因此把 `frontend/README.md` 排除出语料；建议评审决定是否修正该引用或补写真实前端文档。
2. **音频编码 opus vs pcm（待确认，非必然矛盾）**：`ig-voice-arch` 音频规格块第 493 行 `codec: opus`，而 ASR/TTS 配置（457、469 行）`format: pcm`。可能分别描述「WebSocket 传输编码」与「模型输入格式」，需人工确认是否一致。
3. **PostgreSQL 版本表述（非矛盾，仅记录）**：`ig-readme-root` 环境要求写「PostgreSQL 14+」，同文件技术栈表写「Compose 默认 PG16」；`docker-compose.dev.yml` 实际镜像为 `pgvector/pgvector:pg16`。14+ 为最低要求、PG16 为默认，二者不冲突。
4. **Redis 版本表述（非矛盾，仅记录）**：README 写「Redis 6+」，`docker-compose.dev.yml` 实际 `redis:7`，符合「6+」。

## 7. 待审核事项

- [ ] 是否接受把 `.claude/tdd/*.md` 作为产品知识语料（若否，需补充第 6 份非 `.claude` 文档）。
- [ ] 4 道无答案题的判定是否认可（真实答案确在语料之外，语料仅定性提及相关主题）。
- [ ] 行号定位基于 `corpus/` 副本（与原文件逐字节一致）的 1-based 行号，是否满足后续 evidence→chunk 映射需要。
- [ ] chunkId 映射延后到真实切分阶段；本轮不含任何 chunkId。
- [ ] 是否需要为长文档（README、voice-arch）按标题做章节级切分副本，以提升检索区分度（当前为整文件）。

## 8. 目录结构

```
eval/datasets/devsupport-v0.1/
├── corpus/                      # 7 份文档逐字节副本（docId.md）
├── corpus-manifest.json         # docId/路径/来源提交/sha256/范围/主题
├── queries.draft.json           # 20 道问题草案 + evidence 标注
└── README.md                    # 本文件
```

> 本草案**暂不提交**，与 P1-A 提交分开，等待审核。
